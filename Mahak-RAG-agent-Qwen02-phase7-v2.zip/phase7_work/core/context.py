"""
General AI - Conversation Context

مدیریت Context مکالمه برای Agent.
این بخش مستقل از مدل LLM است و برای تست
نیازی به API Key ندارد.
"""

from dataclasses import dataclass, field
from typing import List, Dict, Optional


@dataclass
class ContextMessage:
    role: str
    content: str


@dataclass
class ConversationContext:
    session_id: str
    max_messages: int = 20
    messages: List[ContextMessage] = field(default_factory=list)

    def add(
        self,
        role: str,
        content: str,
    ) -> None:

        if not content or not content.strip():
            return

        self.messages.append(
            ContextMessage(
                role=role,
                content=content.strip(),
            )
        )

        self._trim()

    def _trim(self) -> None:

        if len(self.messages) > self.max_messages:
            self.messages = self.messages[
                -self.max_messages:
            ]

    def clear(self) -> None:
        self.messages.clear()

    def last(
        self,
        count: int = 5,
    ) -> List[ContextMessage]:

        if count <= 0:
            return []

        return self.messages[-count:]

    def as_messages(
        self,
    ) -> List[Dict[str, str]]:

        return [
            {
                "role": message.role,
                "content": message.content,
            }
            for message in self.messages
        ]

    def as_text(
        self,
        count: Optional[int] = None,
    ) -> str:

        messages = (
            self.messages
            if count is None
            else self.last(count)
        )

        if not messages:
            return ""

        lines = []

        for message in messages:
            lines.append(
                f"{message.role}: {message.content}"
            )

        return "\n".join(lines)


class ContextManager:

    def __init__(
        self,
        max_messages: int = 20,
    ):
        self.max_messages = max_messages
        self._sessions: Dict[
            str,
            ConversationContext
        ] = {}

    def get(
        self,
        session_id: str,
    ) -> ConversationContext:

        if session_id not in self._sessions:
            self._sessions[session_id] = (
                ConversationContext(
                    session_id=session_id,
                    max_messages=self.max_messages,
                )
            )

        return self._sessions[session_id]

    def add_user_message(
        self,
        session_id: str,
        content: str,
    ) -> None:

        self.get(session_id).add(
            "user",
            content,
        )

    def add_assistant_message(
        self,
        session_id: str,
        content: str,
    ) -> None:

        self.get(session_id).add(
            "assistant",
            content,
        )

    def get_context(
        self,
        session_id: str,
        count: Optional[int] = None,
    ) -> str:

        return self.get(session_id).as_text(count)

    def clear(
        self,
        session_id: str,
    ) -> None:

        if session_id in self._sessions:
            self._sessions[session_id].clear()


def create_context_manager(
    max_messages: int = 20,
) -> ContextManager:

    return ContextManager(
        max_messages=max_messages
    )


if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI - CONTEXT TEST")
    print("=" * 60)

    manager = create_context_manager(
        max_messages=6
    )

    session = "test-session"

    manager.add_user_message(
        session,
        "سلام"
    )

    manager.add_assistant_message(
        session,
        "سلام! چطور می‌توانم کمک کنم؟"
    )

    manager.add_user_message(
        session,
        "هوش مصنوعی چیست؟"
    )

    manager.add_assistant_message(
        session,
        "هوش مصنوعی مجموعه‌ای از روش‌ها برای ساخت سیستم‌های هوشمند است."
    )

    print()
    print("Conversation context:")
    print("-" * 60)
    print(
        manager.get_context(session)
    )

    print()
    print("Message count:")
    print(
        len(manager.get(session).messages)
    )

    print()
    print("Context test completed successfully.")

    print("=" * 60)