from __future__ import annotations

from dataclasses import dataclass
from typing import List
from urllib.parse import quote_plus

import requests


@dataclass
class WebSearchResult:
    title: str
    url: str
    snippet: str


def _unwrap_ddg(link: str) -> str:
    """DuckDuckGo redirect link (…uddg=…) → real URL."""

    if not link:
        return link

    from urllib.parse import parse_qs, unquote, urlparse

    parsed = urlparse(
        "https:" + link if link.startswith("//") else link
    )

    if "duckduckgo.com" in (parsed.netloc or "") and "l/" in parsed.path:

        target = parse_qs(parsed.query).get("uddg")

        if target:
            return unquote(target[0])

    if link.startswith("//"):
        return "https:" + link

    return link


class WebSearchEngine:

    def __init__(self, timeout: int = 15):
        self.timeout = timeout

    def search(
        self,
        query: str,
        max_results: int = 5,
    ) -> List[WebSearchResult]:

        query = query.strip()

        if not query:
            return []

        url = (
            "https://html.duckduckgo.com/html/"
            f"?q={quote_plus(query)}"
        )

        headers = {
            "User-Agent": (
                "Mozilla/5.0 "
                "(Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 "
                "(KHTML, like Gecko) "
                "Chrome/140.0 Safari/537.36"
            )
        }

        try:
            response = requests.get(
                url,
                headers=headers,
                timeout=self.timeout,
            )

            response.raise_for_status()

        except Exception as exc:

            print(
                f"Web search error: {exc}"
            )

            return []

        try:
            from bs4 import BeautifulSoup

            soup = BeautifulSoup(
                response.text,
                "html.parser",
            )

        except Exception as exc:

            print(
                f"HTML parser error: {exc}"
            )

            return []

        results = []

        for item in soup.select(
            ".result"
        )[:max_results]:

            title_element = item.select_one(
                ".result__title"
            )

            link_element = item.select_one(
                ".result__a"
            )

            snippet_element = item.select_one(
                ".result__snippet"
            )

            if not link_element:
                continue

            title = (
                title_element.get_text(
                    " ",
                    strip=True,
                )
                if title_element
                else link_element.get_text(
                    " ",
                    strip=True,
                )
            )

            link = link_element.get(
                "href",
                "",
            )

            link = _unwrap_ddg(link)

            snippet = (
                snippet_element.get_text(
                    " ",
                    strip=True,
                )
                if snippet_element
                else ""
            )

            results.append(
                WebSearchResult(
                    title=title,
                    url=link,
                    snippet=snippet,
                )
            )

        return results


def create_web_search() -> WebSearchEngine:

    return WebSearchEngine()


if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI WEB SEARCH TEST")
    print("=" * 60)

    engine = WebSearchEngine()

    results = engine.search(
        "latest technology news",
        max_results=5,
    )

    print()
    print("Results:", len(results))

    for index, result in enumerate(
        results,
        start=1,
    ):

        print()
        print(f"Result {index}")
        print("Title:", result.title)
        print("URL:", result.url)
        print("Snippet:", result.snippet)

    print()
    print("Web search test completed.")
