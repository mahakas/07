from __future__ import annotations

from dataclasses import dataclass
from typing import List


@dataclass
class SecurityResult:
    allowed: bool
    text: str
    reason: str = ""


class SecurityGuard:
    """
    لایه امنیتی عمومی برای هوش مصنوعی.

    وظایف فعلی:
    - بررسی ورودی خالی
    - محدود کردن طول درخواست
    - شناسایی برخی درخواست‌های خطرناک
    - پاک‌سازی ورودی
    """

    def __init__(
        self,
        max_input_length: int = 12000,
    ):
        self.max_input_length = max_input_length

        self.blocked_patterns: List[str] = [
            "rm -rf /",
            "del /f /s /q",
            "format c:",
            "format c",
            "shutdown /s",
            "shutdown -h",
            "mkfs",
            ":(){ :|:& };:",
        ]

    # -------------------------------------------------
    # Normalize
    # -------------------------------------------------

    def normalize(self, text: str) -> str:

        if text is None:
            return ""

        return " ".join(
            str(text).strip().split()
        )

    # -------------------------------------------------
    # Length check
    # -------------------------------------------------

    def check_length(self, text: str) -> SecurityResult:

        if len(text) > self.max_input_length:

            return SecurityResult(
                allowed=False,
                text="",
                reason=(
                    "Input exceeds the maximum "
                    "allowed length."
                ),
            )

        return SecurityResult(
            allowed=True,
            text=text,
        )

    # -------------------------------------------------
    # Dangerous pattern check
    # -------------------------------------------------

    def check_dangerous_patterns(
        self,
        text: str,
    ) -> SecurityResult:

        lowered = text.lower()

        for pattern in self.blocked_patterns:

            if pattern.lower() in lowered:

                return SecurityResult(
                    allowed=False,
                    text="",
                    reason=(
                        "Potentially dangerous "
                        "command detected."
                    ),
                )

        return SecurityResult(
            allowed=True,
            text=text,
        )

    # -------------------------------------------------
    # Main validation
    # -------------------------------------------------

    def validate(
        self,
        text: str,
    ) -> SecurityResult:

        normalized = self.normalize(text)

        if not normalized:

            return SecurityResult(
                allowed=False,
                text="",
                reason="Empty input.",
            )

        length_result = self.check_length(
            normalized
        )

        if not length_result.allowed:
            return length_result

        pattern_result = (
            self.check_dangerous_patterns(
                normalized
            )
        )

        if not pattern_result.allowed:
            return pattern_result

        return SecurityResult(
            allowed=True,
            text=normalized,
        )

    # -------------------------------------------------
    # Simple interface
    # -------------------------------------------------

    def is_allowed(
        self,
        text: str,
    ) -> bool:

        return self.validate(text).allowed

    def sanitize(
        self,
        text: str,
    ) -> str:

        result = self.validate(text)

        if not result.allowed:
            return ""

        return result.text


# -----------------------------------------------------
# Factory
# -----------------------------------------------------

def create_security_guard() -> SecurityGuard:

    return SecurityGuard()


# -----------------------------------------------------
# Test
# -----------------------------------------------------

if __name__ == "__main__":

    print("=" * 60)
    print("GENERAL AI SECURITY GUARD TEST")
    print("=" * 60)

    guard = create_security_guard()

    tests = [
        "Hello",
        "What is artificial intelligence?",
        "Calculate 25 * 40",
        "",
        "   ",
        "rm -rf /",
        "format c:",
    ]

    for text in tests:

        result = guard.validate(text)

        print()
        print("-" * 60)
        print("Input:", repr(text))
        print("Allowed:", result.allowed)
        print("Clean text:", repr(result.text))
        print("Reason:", result.reason)

    print()
    print("=" * 60)
    print("SECURITY GUARD TEST COMPLETED")
    print("=" * 60)