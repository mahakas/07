# Mahak AI v2 — Phase 2

Phase 2 establishes the persistent educational catalog and source-management foundation while keeping the legacy application untouched.

## Included

- Grade → Subject → Course → Chapter → Lesson domain hierarchy
- SQLAlchemy repositories for catalog and sources
- Initial Persian catalog seed for grades 7–12
- FastAPI catalog and source endpoints
- Soft-disable endpoints for grades, subjects, and courses
- Source metadata and version foundation
- Source-aware schema contracts for later ingestion/retrieval work

## Run

From the project root:

```bash
python scripts/seed_v2.py
python -m pytest -q tests_v2
python -m compileall -q backend_v2
python -m backend_v2
```

Start the API:

```bash
uvicorn backend_v2.api.app:app --reload
```

Then open `/docs` for the Swagger UI.

## Important

The current seed is only an initial Persian catalog. It is data, not business logic. Future admin functionality can add, disable, reorder, or replace catalog items without changing Python code.
