from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from backend_v2.api.dependencies import get_db
from backend_v2.database.repositories import CatalogRepository, SourceRepository
from backend_v2.schemas import SourceCreate, SourceOut

router = APIRouter(prefix="/sources", tags=["sources"])


@router.get("", response_model=list[SourceOut])
def list_sources(course_id: str | None = None, db: Session = Depends(get_db)):
    return SourceRepository(db).list(course_id=course_id)


@router.post("", response_model=SourceOut, status_code=status.HTTP_201_CREATED)
def create_source(payload: SourceCreate, db: Session = Depends(get_db)):
    catalog = CatalogRepository(db)
    course = catalog.get_course(payload.course_id)
    if not course:
        raise HTTPException(404, "Course not found")
    source = SourceRepository(db).create(
        title=payload.title,
        source_type=payload.source_type,
        course_id=payload.course_id,
        grade_id=course.subject.grade_id if course.subject else None,
        subject_id=course.subject_id,
        chapter_id=payload.chapter_id,
        lesson_id=payload.lesson_id,
        original_url=payload.original_url,
        storage_key=payload.storage_key,
        metadata_json=payload.metadata_json,
    )
    db.commit()
    return source
