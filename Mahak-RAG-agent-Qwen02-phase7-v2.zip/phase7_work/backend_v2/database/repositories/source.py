from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend_v2.database.models import Source, SourceVersion


class SourceRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def get(self, source_id: str) -> Source | None:
        return self.db.get(Source, source_id)

    def list(self, *, course_id: str | None = None, status=None, limit: int = 100) -> list[Source]:
        stmt = select(Source).order_by(Source.created_at.desc()).limit(limit)
        if course_id:
            stmt = stmt.where(Source.course_id == course_id)
        if status is not None:
            stmt = stmt.where(Source.status == status)
        return list(self.db.scalars(stmt).unique())

    def create(self, **kwargs) -> Source:
        source = Source(**kwargs)
        self.db.add(source)
        self.db.flush()
        return source

    def add_version(self, source_id: str, version_number: int, checksum: str | None = None, extracted_text: str | None = None, metadata_json: dict | None = None) -> SourceVersion:
        version = SourceVersion(
            source_id=source_id,
            version_number=version_number,
            checksum=checksum,
            extracted_text=extracted_text,
            metadata_json=metadata_json or {},
        )
        self.db.add(version)
        self.db.flush()
        return version
