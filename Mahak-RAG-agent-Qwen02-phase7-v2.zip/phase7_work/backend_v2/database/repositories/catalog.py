from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from backend_v2.database.models import Chapter, Course, Grade, Lesson, Subject


class CatalogRepository:
    def __init__(self, db: Session) -> None:
        self.db = db

    def list_grades(self, active_only: bool = True) -> list[Grade]:
        stmt = select(Grade).order_by(Grade.sort_order, Grade.name)
        if active_only:
            stmt = stmt.where(Grade.is_active.is_(True))
        return list(self.db.scalars(stmt).unique())

    def get_grade(self, grade_id: str) -> Grade | None:
        return self.db.get(Grade, grade_id)

    def get_grade_by_name(self, name: str) -> Grade | None:
        return self.db.scalar(select(Grade).where(Grade.name == name))

    def create_grade(self, name: str, sort_order: int = 0) -> Grade:
        grade = Grade(name=name.strip(), sort_order=sort_order)
        self.db.add(grade)
        self.db.flush()
        return grade

    def list_subjects(self, grade_id: str, active_only: bool = True) -> list[Subject]:
        stmt = select(Subject).where(Subject.grade_id == grade_id).order_by(Subject.sort_order, Subject.name)
        if active_only:
            stmt = stmt.where(Subject.is_active.is_(True))
        return list(self.db.scalars(stmt).unique())

    def get_subject(self, subject_id: str) -> Subject | None:
        return self.db.get(Subject, subject_id)

    def get_subject_by_name(self, grade_id: str, name: str) -> Subject | None:
        return self.db.scalar(select(Subject).where(Subject.grade_id == grade_id, Subject.name == name))

    def create_subject(self, grade_id: str, name: str, sort_order: int = 0) -> Subject:
        subject = Subject(grade_id=grade_id, name=name.strip(), sort_order=sort_order)
        self.db.add(subject)
        self.db.flush()
        return subject

    def list_courses(self, subject_id: str, active_only: bool = True) -> list[Course]:
        stmt = select(Course).where(Course.subject_id == subject_id).order_by(Course.name)
        if active_only:
            stmt = stmt.where(Course.is_active.is_(True))
        return list(self.db.scalars(stmt).unique())

    def get_course(self, course_id: str) -> Course | None:
        return self.db.get(Course, course_id)

    def create_course(self, subject_id: str, name: str, description: str | None = None) -> Course:
        course = Course(subject_id=subject_id, name=name.strip(), description=description)
        self.db.add(course)
        self.db.flush()
        return course

    def list_chapters(self, course_id: str, active_only: bool = True) -> list[Chapter]:
        stmt = select(Chapter).where(Chapter.course_id == course_id).order_by(Chapter.sort_order, Chapter.name)
        return list(self.db.scalars(stmt).unique())

    def create_chapter(self, course_id: str, name: str, sort_order: int = 0) -> Chapter:
        chapter = Chapter(course_id=course_id, name=name.strip(), sort_order=sort_order)
        self.db.add(chapter)
        self.db.flush()
        return chapter

    def list_lessons(self, chapter_id: str) -> list[Lesson]:
        stmt = select(Lesson).where(Lesson.chapter_id == chapter_id).order_by(Lesson.sort_order, Lesson.name)
        return list(self.db.scalars(stmt).unique())

    def create_lesson(self, chapter_id: str, name: str, sort_order: int = 0) -> Lesson:
        lesson = Lesson(chapter_id=chapter_id, name=name.strip(), sort_order=sort_order)
        self.db.add(lesson)
        self.db.flush()
        return lesson
