# Vector & Embedding layer — v2

Phase 5 introduces three separate concerns:

1. `EmbeddingService` routes embedding requests through the Provider Orchestrator.
2. `ChromaVectorStore` is a concrete implementation of the generic `VectorStore` contract.
3. `VectorIndexService` treats embedding compatibility and index versioning as first-class concerns.

The application core never depends directly on Chroma APIs. If the vector backend changes later, add another adapter under `vectorstores/` and keep retrieval unchanged.

## Compatibility rule

An index has an `embedding_profile_id`, embedding version, dimension, and backend collection version. Embeddings with a different dimension are rejected rather than silently inserted into an incompatible index.
