from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence
from uuid import uuid4

from backend_v2.vectorstores.base import VectorRecord
from backend_v2.vectorstores.chroma import ChromaVectorStore
from backend_v2.vectorstores.embedding import EmbeddingResult


@dataclass(frozen=True, slots=True)
class IndexSpec:
    logical_name: str
    embedding_profile_id: str
    embedding_version: str
    dimension: int
    distance_metric: str = "cosine"
    version: int = 1

    @property
    def collection_name(self) -> str:
        safe = self.logical_name.replace("/", "_").replace(" ", "_")
        return f"{safe}__v{self.version}__{self.embedding_version}"


class VectorIndexService:
    """Keeps vector index identity/versioning separate from the vector backend."""

    def __init__(self, store: ChromaVectorStore) -> None:
        self.store = store

    @staticmethod
    def compatible(spec: IndexSpec, embedding: EmbeddingResult) -> bool:
        return spec.dimension == embedding.dimension

    def upsert_texts(
        self,
        spec: IndexSpec,
        texts: Sequence[str],
        embedding: EmbeddingResult,
        *,
        metadata: Sequence[dict] | None = None,
    ) -> list[str]:
        if not self.compatible(spec, embedding):
            raise ValueError(
                f"Embedding dimension {embedding.dimension} is incompatible with index dimension {spec.dimension}"
            )
        if len(texts) != len(embedding.vectors):
            raise ValueError("Text count and embedding count must match")
        metas = list(metadata or [{} for _ in texts])
        if len(metas) != len(texts):
            raise ValueError("Metadata count and text count must match")
        records = [
            VectorRecord(
                id=str(uuid4()),
                embedding=vector,
                document=text,
                metadata={**meta, "index_version": spec.version, "embedding_version": spec.embedding_version},
            )
            for text, vector, meta in zip(texts, embedding.vectors, metas)
        ]
        self.store.upsert(records, collection=spec.collection_name)
        return [record.id for record in records]
