from __future__ import annotations

from dataclasses import dataclass

from backend_v2.chat.context import ConversationContext
from backend_v2.core.enums import Capability, ChatMode


@dataclass(frozen=True, slots=True)
class RetrievalPlan:
    enabled: bool
    allow_web: bool
    capabilities: tuple[Capability, ...]
    reason: str


class QueryPlanner:
    def plan(self, context: ConversationContext, has_file: bool = False) -> RetrievalPlan:
        if context.mode is ChatMode.EDUCATIONAL:
            capabilities = [Capability.CHAT, Capability.EMBEDDING]
            if has_file:
                capabilities.append(Capability.VISION)
            return RetrievalPlan(
                enabled=True,
                allow_web=False,
                capabilities=tuple(capabilities),
                reason="educational scope uses private knowledge and session files",
            )

        return RetrievalPlan(
            enabled=False,
            allow_web=True,
            capabilities=(Capability.CHAT,),
            reason="general chat is open-world and may use web search",
        )
