from __future__ import annotations

import hashlib
from typing import Any, Callable

from backend_v2.core.enums import Capability
from backend_v2.providers.contracts import ProviderRequest, ProviderResponse


class MockProviderAdapter:
    """Deterministic adapter used by tests and local development."""

    def __init__(
        self,
        provider_name: str,
        capabilities: set[Capability],
        handler: Callable[[Any], Any] | None = None,
        *,
        default_model: str | None = None,
        embedding_dimension: int = 8,
    ) -> None:
        self.provider_name = provider_name
        self._capabilities = set(capabilities)
        self._handler = handler
        self.default_model = default_model or provider_name
        self.embedding_dimension = embedding_dimension

    def supports(self, capability: Capability) -> bool:
        return capability in self._capabilities

    def execute(self, request: ProviderRequest) -> ProviderResponse:
        if request.capability is Capability.EMBEDDING:
            texts = request.payload.get("texts", []) if isinstance(request.payload, dict) else []
            vectors = [self._embed(str(text)) for text in texts]
            return ProviderResponse(vectors, self.provider_name, request.model)
        output = self._handler(request.payload) if self._handler else request.payload
        return ProviderResponse(output, self.provider_name, request.model)

    def _embed(self, text: str) -> list[float]:
        raw = hashlib.sha256(text.encode("utf-8")).digest()
        return [((raw[i] / 255.0) * 2.0) - 1.0 for i in range(self.embedding_dimension)]

    def health_check(self, capability: Capability | None = None) -> bool:
        return capability is None or self.supports(capability)
