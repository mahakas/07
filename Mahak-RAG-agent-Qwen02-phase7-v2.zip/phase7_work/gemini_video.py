"""
Provider گوگل گمینی — ایجنت مهک

از SDK رسمی فعلی google-genai استفاده می‌کند (جانشین رسماً deprecated
شدهٔ google-generativeai). جریان کار طبق مستندات رسمی:

    client.files.upload(file=...)          ← File API (Developer API)
    client.files.get(name=...)             ← polling تا state=ACTIVE
    client.models.generate_content(...)    ← تحلیل ویدئو + prompt

محدودیت‌های واقعی که در طراحی دیده شده‌اند:
  - نمونه‌برداری ویدئو با FPS=1 → ویدئوی خیلی بلند در یک درخواست
    جا نمی‌شود؛ برای همین پنجره‌بندی زمانی انجام می‌شود و هر پنجره
    جداگانه تحلیل می‌گردد. (پنجره‌ها توسط video_ingest ساخته می‌شوند)
  - state فایل ممکن است FAILED شود (کدک/حجم) → خطای گویا
  - ریت‌لیمیت و timeout → عقب‌نشینی نمایی مثل بقیهٔ پروژه
  - audio-only/بدون تصویر: Gemini خودش handle می‌کند؛ ما فقط
    محتوای خالی را به‌عنوان شکست سگمنت ثبت می‌کنیم نه کرش.

نکتهٔ مهم: این فایل هرگز timestamp اختراع نمی‌کند. هر چیزی که در
خروجی می‌آید یا از پنجرهٔ خودش است (start/end واقعی فایل) یا از
پاسخ مدل برای همان پنجره — و لایهٔ citation فقط متادیتا را نمایش می‌دهد.
"""

import json
import time
from typing import List, Dict

from video_provider import (
    VideoUnderstandingProvider,
    VideoUnderstandingError,
    SegmentResult,
    POLL_MAX_TRIES,
    POLL_INTERVAL,
)

import config


class GeminiVideoProvider(VideoUnderstandingProvider):
    """درک ویدئو با Google Gemini (File API + generate_content)."""

    name = "gemini"

    def __init__(self):
        if not config.GEMINI_API_KEY:
            raise VideoUnderstandingError(
                "GEMINI_API_KEY در فایل .env پیدا نشد. "
                "کلید رایگان را از aistudio.google.com بگیر.",
                kind="config",
            )
        try:
            from google import genai
        except ImportError:
            raise VideoUnderstandingError(
                "کتابخانهٔ google-genai نصب نیست. اجرا کن:  pip install google-genai",
                kind="config",
            )
        self._client = genai.Client(api_key=config.GEMINI_API_KEY)
        self._model = self._normalize_model_name(
            config.GEMINI_VIDEO_MODEL
        )

    @staticmethod
    def _normalize_model_name(model_name):
        """تبدیل نام خوانا به شناسهٔ قابل قبول Gemini در صورت نیاز."""
        model_name = (model_name or "").strip()
        if model_name.startswith("models/"):
            return model_name
        if " " in model_name:
            return "models/" + model_name.lower().replace(" ", "-")
        return model_name

    # ------------------------------------------------------------ API

    def understand(self, path, windows, progress=None):
        """
        path: مسیر فایل ویدئو
        windows: [{"start": float, "end": float}, ...]
        progress: callback(پیام, درصد) برای نمایش در UI
        """
        self.check_file(path)
        results = []
        total = len(windows)

        try:
            for i, w in enumerate(windows):
                if progress:
                    progress(
                        f"تحلیل ویدئو — پنجرهٔ {i + 1} از {total}",
                        int(100 * i / max(total, 1)),
                    )

                seg = self._analyze_window(path, w["start"], w["end"])
                if seg is not None:
                    results.append(seg)

        finally:
            self._release_upload()

        if not results:
            raise VideoUnderstandingError(
                "هیچ سگمنتی از ویدئو تحلیل نشد. ممکن است فایل خراب، "
                "بدون صدا/تصویر باشد یا سهمیهٔ API تمام شده باشد.",
                kind="fatal",
            )
        return results

    def understand_url(self, url, windows, progress=None):
        """
        تحلیل مستقیم لینک یوتیوب — بدون دانلود و بدون آپلود.
        گوگل خودش ویدئوی لینک را با file_uri می‌خواند؛ ما فقط
        پنجره‌های زمانی را جدا تحلیل می‌کنیم تا timestampها واقعی بمانند.
        """
        results = []
        total = len(windows)

        for i, w in enumerate(windows):
            if progress:
                progress(
                    f"تحلیل یوتیوب — پنجرهٔ {i + 1} از {total}",
                    int(100 * i / max(total, 1)),
                )

            try:
                seg = self._generate_uri(url, w["start"], w["end"])
            except VideoUnderstandingError as e:
                if e.kind == "rate_limit":
                    raise
                print(f"  [!] پنجرهٔ {w['start']:.0f}-{w['end']:.0f} تحلیل نشد: {e}")
                continue
            if seg is not None:
                results.append(seg)

        if not results:
            raise VideoUnderstandingError(
                "هیچ سگمنتی از ویدئوی یوتیوب تحلیل نشد. ممکن است لینک "
                "خصوصی/ناموجود باشد، زیرنویس/صدا نداشته باشد یا سهمیهٔ "
                "API تمام شده باشد.",
                kind="fatal",
            )
        return results

    # ------------------------------------------------------ داخلی

    def _analyze_window(self, path, start, end):
        """یک پنجرهٔ زمانی را تحلیل می‌کند (آپلود فایل کش میشود)."""
        uploaded = getattr(self, "_upload_cache", None)
        cached_path = getattr(self, "_upload_cache_path", None)

        if uploaded is None or cached_path != path:

            if uploaded is not None:
                self._delete(uploaded)

            uploaded = self._upload(path)
            self._wait_active(uploaded)
            self._upload_cache = uploaded
            self._upload_cache_path = path

        try:
            return self._generate(uploaded, start, end)
        except VideoUnderstandingError as e:
            if e.kind == "rate_limit":
                raise  # برای ریت‌لیمیت ارزش صبر دارد
            print(f"  [!] پنجرهٔ {start:.0f}-{end:.0f} تحلیل نشد: {e}")
            return None

    def _release_upload(self):
        """آزاد کردن فایل آپلودی در پایان تحلیل همهٔ پنجره‌ها."""
        uploaded = getattr(self, "_upload_cache", None)
        if uploaded is not None:
            self._delete(uploaded)
            self._upload_cache = None
            self._upload_cache_path = None

    def _upload(self, path):
        last_err = None
        for attempt in range(3):
            try:
                return self._client.files.upload(file=path)
            except Exception as e:
                last_err = e
                msg = str(e)
                if self._is_rate_limit(msg) and attempt < 2:
                    self.backoff(attempt)
                    continue
                if self._is_auth(msg):
                    raise VideoUnderstandingError(
                        "کلید GEMINI_API_KEY نامعتبر است.", kind="config"
                    )
                break
        raise VideoUnderstandingError(
            f"آپلود ویدئو به گوگل ناموفق بود: "
            f"{type(last_err).__name__}: {last_err}",
            kind="fatal",
        )

    def _wait_active(self, f):
        """انتظار تا آماده شدن فایل روی File API (معمولاً چند ثانیه)."""
        name = getattr(f, "name", None)
        if not name:
            return
        for _ in range(POLL_MAX_TRIES):
            try:
                f = self._client.files.get(name=name)
            except Exception as e:
                raise VideoUnderstandingError(
                    f"چک وضعیت فایل ناموفق: {e}", kind="timeout"
                )
            state = getattr(getattr(f, "state", None), "name", "")
            if state == "ACTIVE":
                return
            if state == "FAILED":
                raise VideoUnderstandingError(
                    "گوگل پردازش این فایل را رد کرد (احتمالاً کدک یا "
                    "فرمت پشتیبانی نمی‌شود). فایل را با mp4/H.264 تست کن.",
                    kind="corrupt",
                )
            time.sleep(POLL_INTERVAL)
        raise VideoUnderstandingError(
            "فایل بیش از حد انتظار روی سرور گوگل معطل ماند.",
            kind="timeout",
        )

    def _generate(self, uploaded_file, start, end):
        """تحلیل یک پنجره با پرامپت JSON-محور."""
        t0 = int(start)
        t1 = int(end)

        vision = config.VIDEO_ENABLE_VISION
        audio = config.VIDEO_ENABLE_AUDIO

        p = f"""این ویدئوی آموزشی را از ثانیهٔ {t0} تا {t1} تحلیل کن.

{'۱. گفتار گوینده (transcript): دقیق و روان، فارسی محاورهٔ همان چیزی که گفته می‌شود. اگر هیچ صدایی نیست بنویس: هیچ' if audio else 'گفتار را نادیده بگیر.'}
{'۲. توصیف تصویری (visual): متن روی صفحه، اسلاید، کد داخل ادیتور، نمودار، UI — هرچه دیده می‌شود.' if vision else 'تصویر را نادیده بگیر.'}

خروجی را فقط به شکل JSON بده، بدون هیچ متن اضافه:
{{
  "transcript": "...",
  "visual_description": "...",
  "code": "کدهای دیده‌شده روی صفحه یا خالی",
  "content_type": "audio" یا "visual" یا "mixed"
}}"""

        last_err = None
        for attempt in range(3):
            try:
                resp = self._client.models.generate_content(
                    model=self._model,
                    contents=[p, uploaded_file],
                    config={"temperature": 0.1},
                )
                return self._parse(resp, start, end)
            except Exception as e:
                last_err = e
                msg = str(e)
                if self._is_rate_limit(msg) and attempt < 2:
                    self.backoff(attempt)
                    continue
                break

        raise VideoUnderstandingError(
            f"تحلیل Gemini ناموفق: {type(last_err).__name__}: {last_err}",
            kind="timeout",
        )

    def _generate_uri(self, url, start, end):
        """
        تحلیل یک پنجره از ویدئوی یوتیوب با file_uri — گوگل خودش ویدئو را
        می‌خواند؛ هیچ آپلودی انجام نمی‌شود. timestamp از پنجرهٔ واقعی است.
        """
        t0 = int(start)
        t1 = int(end)

        vision = config.VIDEO_ENABLE_VISION
        audio = config.VIDEO_ENABLE_AUDIO

        p = f"""این ویدئوی آموزشی یوتیوب را از ثانیهٔ {t0} تا {t1} تحلیل کن.

{'۱. گفتار گوینده (transcript): دقیق و روان، فارسی محاورهٔ همان چیزی که گفته می‌شود. اگر هیچ صدایی نیست بنویس: هیچ' if audio else 'گفتار را نادیده بگیر.'}
{'۲. توصیف تصویری (visual): متن روی صفحه، اسلاید، کد داخل ادیتور، نمودار، UI — هرچه دیده می‌شود.' if vision else 'تصویر را نادیده بگیر.'}

خروجی را فقط به شکل JSON بده، بدون هیچ متن اضافه:
{{
  "transcript": "...",
  "visual_description": "...",
  "code": "کدهای دیده‌شده روی صفحه یا خالی",
  "content_type": "audio" یا "visual" یا "mixed"
}}"""

        part = {
            "file_data": {
                "file_uri": url,
                "mime_type": "video/mp4",
            },
        }

        last_err = None
        for attempt in range(3):
            try:
                resp = self._client.models.generate_content(
                    model=self._model,
                    contents=[p, part],
                    config={"temperature": 0.1},
                )
                return self._parse(resp, start, end)
            except Exception as e:
                last_err = e
                msg = str(e)
                if self._is_rate_limit(msg) and attempt < 2:
                    self.backoff(attempt)
                    continue
                if self._is_not_found(msg):
                    raise VideoUnderstandingError(
                        "ویدئوی یوتیوب پیدا نشد یا در دسترس نیست "
                        "(خصوصی، حذف‌شده یا محدود منطقه‌ای).",
                        kind="fatal",
                    )
                break

        raise VideoUnderstandingError(
            f"تحلیل یوتیوب Gemini ناموفق: {type(last_err).__name__}: {last_err}",
            kind="timeout",
        )

    @staticmethod
    def _is_not_found(msg):
        low = msg.lower()
        return ("404" in msg or "not found" in low
                or "video_not_found" in low or "private" in low)

    def _parse(self, resp, start, end):
        """JSON خروجی مدل را می‌خواند؛ timestamp از پنجرهٔ واقعی می‌آید."""
        raw = (getattr(resp, "text", "") or "").strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        try:
            data = json.loads(raw)
        except json.JSONDecodeError:
            # مدل گاهی JSON را با متن قاطی می‌کند؛ اولین { تا آخرین }
            s, e2 = raw.find("{"), raw.rfind("}")
            if s == -1 or e2 <= s:
                raise VideoUnderstandingError(
                    "خروجی Gemini قابل تجزیه نبود.", kind="timeout"
                )
            data = json.loads(raw[s:e2 + 1])

        transcript = str(data.get("transcript", "") or "").strip()
        visual = str(data.get("visual_description", "") or "").strip()
        code = str(data.get("code", "") or "").strip()
        ctype = str(data.get("content_type", "") or "").strip().lower()

        if not transcript and not visual:
            return None   # پنجرهٔ خالی — نه کرش، نه محتوای الکی

        if ctype not in ("audio", "visual", "mixed"):
            ctype = "mixed" if (transcript and visual) else (
                "audio" if transcript else "visual"
            )

        return SegmentResult(
            start_time=float(start),
            end_time=float(end),
            transcript=transcript,
            visual_description=visual,
            code=code,
            content_type=ctype,
        )

    # ------------------------------------------------------ کمکی

    @staticmethod
    def _is_rate_limit(msg):
        return "429" in msg or "Too Many Requests" in msg or "RESOURCE_EXHAUSTED" in msg

    @staticmethod
    def _is_auth(msg):
        return "API key" in msg or "API_KEY" in msg or "401" in msg or "403" in msg

    def _delete(self, f):
        """حذف فایل آپلودشده — سهمیهٔ File API اشغال نماند."""
        name = getattr(f, "name", None)
        if not name:
            return
        try:
            self._client.files.delete(name=name)
        except Exception:
            pass  # حذف ناموفق نباید pipeline را بکشد
