"""Qwen video understanding provider through an OpenAI-compatible API."""

import base64
import json
from pathlib import Path

import requests

import config
from video_provider import SegmentResult, VideoUnderstandingError, VideoUnderstandingProvider


class QwenVideoProvider(VideoUnderstandingProvider):
    """Analyze video windows with a Qwen multimodal chat endpoint."""

    name = "qwen"

    def __init__(self):
        if not config.QWEN_API_KEY:
            raise VideoUnderstandingError(
                "QWEN_API_KEY در فایل .env پیدا نشد.",
                kind="config",
            )
        if not config.QWEN_BASE_URL:
            raise VideoUnderstandingError(
                "QWEN_BASE_URL در فایل .env تنظیم نشده است.",
                kind="config",
            )
        self._endpoint = config.QWEN_BASE_URL.rstrip("/") + "/chat/completions"
        self._model = config.QWEN_VIDEO_MODEL

    def understand(self, path, windows, progress=None):
        self.check_file(path)
        video_ref = self._local_video_reference(path)
        return self._analyze_windows(video_ref, windows, progress)

    def understand_url(self, url, windows, progress=None):
        return self._analyze_windows(url, windows, progress)

    def _analyze_windows(self, video_ref, windows, progress):
        results = []
        total = len(windows)

        for index, window in enumerate(windows):
            if progress:
                progress(
                    f"تحلیل ویدئو با Qwen - پنجرهٔ {index + 1} از {total}",
                    int(100 * index / max(total, 1)),
                )
            try:
                result = self._generate(video_ref, window["start"], window["end"])
            except VideoUnderstandingError as error:
                if error.kind == "rate_limit":
                    raise
                print(
                    f"  [!] پنجرهٔ {window['start']:.0f}-{window['end']:.0f} "
                    f"تحلیل نشد: {error}"
                )
                continue
            if result is not None:
                results.append(result)

        if not results:
            raise VideoUnderstandingError(
                "هیچ سگمنتی با Qwen تحلیل نشد.",
                kind="fatal",
            )
        return results

    def _generate(self, video_ref, start, end):
        prompt = self._prompt(start, end)
        payload = {
            "model": self._model,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "video_url",
                            "video_url": {"url": video_ref},
                        },
                    ],
                }
            ],
            "temperature": 0.1,
            "max_tokens": 2048,
        }

        try:
            response = requests.post(
                self._endpoint,
                headers={
                    "Authorization": f"Bearer {config.QWEN_API_KEY}",
                    "Content-Type": "application/json",
                },
                json=payload,
                timeout=config.QWEN_TIMEOUT,
            )
            if response.status_code == 429:
                raise VideoUnderstandingError(
                    "سهمیه یا نرخ درخواست Qwen تمام شده است.",
                    kind="rate_limit",
                )
            response.raise_for_status()
            data = response.json()
            content = data["choices"][0]["message"]["content"]
        except VideoUnderstandingError:
            raise
        except (requests.RequestException, KeyError, IndexError, TypeError, ValueError) as error:
            raise VideoUnderstandingError(
                f"درخواست Qwen ناموفق بود: {type(error).__name__}: {error}",
                kind="timeout",
            ) from error

        return self._parse(content, start, end)

    @staticmethod
    def _local_video_reference(path):
        """Use a data URL for local files accepted by compatible endpoints."""
        encoded = base64.b64encode(Path(path).read_bytes()).decode("ascii")
        return f"data:video/mp4;base64,{encoded}"

    @staticmethod
    def _prompt(start, end):
        return f"""این ویدئو را از ثانیهٔ {int(start)} تا {int(end)} تحلیل کن.
گفتار را دقیق به فارسی بنویس و متن روی صفحه، کد و تصویر مهم را توضیح بده.
فقط JSON معتبر و بدون Markdown برگردان:
{{
  "transcript": "...",
  "visual_description": "...",
  "code": "...",
  "content_type": "audio یا visual یا mixed"
}}"""

    @staticmethod
    def _parse(content, start, end):
        if isinstance(content, list):
            content = "".join(
                item.get("text", "") for item in content if isinstance(item, dict)
            )
        raw = str(content or "").strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1].removeprefix("json").strip()
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as error:
            raise VideoUnderstandingError(
                "خروجی Qwen JSON معتبر نبود.",
                kind="timeout",
            ) from error

        transcript = str(data.get("transcript", "") or "").strip()
        visual = str(data.get("visual_description", "") or "").strip()
        code = str(data.get("code", "") or "").strip()
        if not transcript and not visual and not code:
            return None
        content_type = str(data.get("content_type", "mixed") or "mixed").lower()
        if content_type not in {"audio", "visual", "mixed"}:
            content_type = "mixed"
        return SegmentResult(
            start_time=float(start),
            end_time=float(end),
            transcript=transcript,
            visual_description=visual,
            code=code,
            content_type=content_type,
        )