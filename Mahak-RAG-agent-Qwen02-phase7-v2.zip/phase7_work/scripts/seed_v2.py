from __future__ import annotations

from pathlib import Path
import sys

# Allow `python scripts/seed_v2.py` from the project root.
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from sqlalchemy import select

from backend_v2.database.connection import SessionLocal, create_all
from backend_v2.database.models import Grade, Subject

# Initial Persian catalog. Admin can add/remove later through the API.
DEFAULT_CATALOG = {
    "هفتم": ["ریاضی", "علوم تجربی", "فارسی", "نگارش", "عربی", "انگلیسی", "مطالعات اجتماعی"],
    "هشتم": ["ریاضی", "علوم تجربی", "فارسی", "نگارش", "عربی", "انگلیسی", "مطالعات اجتماعی"],
    "نهم": ["ریاضی", "علوم تجربی", "فارسی", "نگارش", "عربی", "انگلیسی", "مطالعات اجتماعی"],
    "دهم": ["ریاضی", "فیزیک", "شیمی", "زیست‌شناسی", "فارسی", "نگارش", "عربی", "انگلیسی"],
    "یازدهم": ["ریاضی", "فیزیک", "شیمی", "زیست‌شناسی", "فارسی", "نگارش", "عربی", "انگلیسی"],
    "دوازدهم": ["ریاضی", "فیزیک", "شیمی", "زیست‌شناسی", "فارسی", "نگارش", "عربی", "انگلیسی"],
}


def seed() -> None:
    create_all()
    db = SessionLocal()
    try:
        for order, (grade_name, subjects) in enumerate(DEFAULT_CATALOG.items(), start=1):
            grade = db.scalar(select(Grade).where(Grade.name == grade_name))
            if grade is None:
                grade = Grade(name=grade_name, sort_order=order)
                db.add(grade)
                db.flush()
            for subject_order, subject_name in enumerate(subjects, start=1):
                exists = db.scalar(select(Subject).where(Subject.grade_id == grade.id, Subject.name == subject_name))
                if exists is None:
                    db.add(Subject(grade_id=grade.id, name=subject_name, sort_order=subject_order))
        db.commit()
        print("Seed completed successfully.")
    finally:
        db.close()


if __name__ == "__main__":
    seed()
